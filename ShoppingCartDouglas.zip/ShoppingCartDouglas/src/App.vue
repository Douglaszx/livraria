<script setup>
import MeuCarrinho from '@/components/MeuCarrinho.vue'
import ListagemLivros from '@/components/ListagemLivros.vue'
</script>

<template>
  <h1>Livraria  duBAGS</h1>
  <div class="container-geral">
    <listagem-livros />
    <meu-carrinho />
  </div>
</template>

<style scoped>

.container-geral {
  /* display: flex;
  justify-content: space-between; */
  display: grid;
  grid-template-columns: 3fr 1fr;
}
h1 {
  font-family: 'arial', cursive;
  text-align: center;
  padding: 5px;
  color: rgb(0, 0, 0);
  background-color: rgb(255, 255, 255);
  border-radius: 10px;
  
}
</style>
