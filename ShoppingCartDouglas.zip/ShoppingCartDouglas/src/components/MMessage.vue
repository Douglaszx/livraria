<script setup>

</script>

<template>
    <p>Empty Cart</p>
</template>

<style scoped>

p{
    font-family: 'Mukta', sans-serif;
    font-size: 1.2rem;
    color: white;
}
</style>